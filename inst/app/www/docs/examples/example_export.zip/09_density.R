# The General | standalone dashboard analysis
# Run from the folder containing this script and its CSV files (R >= 4.1).
# The settings reproduce the current dashboard view at download time.
# Use mapped CSV data from the export, not the original uncleaned upload.
# PNG and analysis CSV outputs are written into this working directory.

# 1. Packages -------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(stringr)
# readr is called explicitly below. No Shiny or thegeneral installation is needed.

# 2. Settings -------------------------------------------------------------
data_file <- "dashboard_data.csv"
output_prefix <- "09_density"
plot_title <- "Example density"
group_column <- "Cat_group"
numeric_column <- "Num_value"
selected_year <- "2024-25"

# 3. Read and prepare data ------------------------------------------------
# Read text first so categorical codes such as 0012 keep their leading zeros.
# Parse only the mapped numeric measures. Rename columns to readable roles.
dashboard_data <-
  readr::read_csv(
    data_file,
    col_types = readr::cols(.default = readr::col_character()),
    na = "",
    show_col_types = FALSE
  ) |>
  transmute(
    group = factor(.data[[group_column]]),
    value = readr::parse_double(.data[[numeric_column]]),
    financial_year = .data$Financial_Year
  )

# 4. Analyse --------------------------------------------------------------
# Match this dashboard view: exclude zero, negative and missing values.
dashboard_data <- dashboard_data |> filter(value > 0)

# Keep the selected financial year and complete observations.
analysis_data <- dashboard_data |>
  filter(financial_year == selected_year) |>
  drop_na(group, value)

# Match the dashboard: retain the pooled 5th-95th percentile range, inclusive.
# These cutoffs are calculated across groups, not separately within each group.
cutoffs <- quantile(analysis_data$value, probs = c(0.05, 0.95), na.rm = TRUE)
analysis_data <- analysis_data |>
  filter(between(value, cutoffs[[1]], cutoffs[[2]])) |>
  transmute(group = droplevels(group), value)

# 5. Plot -----------------------------------------------------------------
# The General's palette, in the same order as the dashboard.
palette <- c("#333333", "#17a2b8", "#eb8596", "#5c6b3c", "#d32f2f", "#e6b950", "#e0e0e0", 
"#90caf9", "#8e24aa", "#fcbb69", "#fdd835", "#1e88e5", "#bdbdbd", "#5e35b1", 
"#ff7043", "#00bfa5", "#ff4081", "#3949ab", "#f44336", "#c2185b", "#7b1fa2", 
"#512da8", "#303f9f", "#0288d1", "#0097a7", "#00796b", "#388e3c", "#689f38", 
"#afb42b", "#f57c00")

# Kernel density curves compare distribution shapes after trimming.
# Each group's curve has area one: heights are density, not sample counts.
# The default bandwidth controls smoothing; small groups can be unstable.
plot <- ggplot(analysis_data, aes(value, fill = group)) +
  geom_density(alpha = 0.5) +
  scale_fill_manual(values = palette) +
  labs(x = numeric_column, y = "Density", fill = group_column)

plot <- plot +
  theme_classic(base_size = 15) +
  theme(
    text = element_text(colour = "#333333"),
    axis.text = element_text(colour = "#333333"),
    legend.text = element_text(size = 10)
  ) +
  labs(title = plot_title)

# 6. Save and display -----------------------------------------------------
# Save the calculated values as well as the image so the result is inspectable.
readr::write_csv(analysis_data, paste0(output_prefix, "_data.csv"), na = "")
ggsave(
  filename = paste0(output_prefix, ".png"),
  plot = plot,
  width = 9, height = 5.5, units = "in", dpi = 300
)

if (interactive()) print(plot)
