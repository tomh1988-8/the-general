# The General | standalone dashboard analysis
# Run from the folder containing this script and its CSV files (R >= 4.1).
# The settings reproduce the current dashboard view at download time.
# Use mapped CSV data from the export, not the original uncleaned upload.
# PNG and analysis CSV outputs are written into this working directory.

# 1. Packages -------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(stringr)
# readr is called explicitly below. No Shiny or thegeneral installation is needed.

# 2. Settings -------------------------------------------------------------
data_file <- "dashboard_data.csv"
# Full mapped data before the Home filter, for the All comparison.
reference_file <- "dashboard_all_data.csv"
output_prefix <- "01_line_single"
plot_title <- "Example line_single"
time_column <- "Month"
time_levels <- c("Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", 
"Mar")
numeric_column <- "Num_value"
# NA leaves that end of the y-axis automatic; limits zoom without dropping rows.
y_limits <- c(NA_real_, NA_real_)

# 3. Read and prepare data ------------------------------------------------
# Read text first so categorical codes such as 0012 keep their leading zeros.
# Parse only the mapped numeric measures. Rename columns to readable roles.
read_analysis_data <- function(path) {
  readr::read_csv(
    path,
    col_types = readr::cols(.default = readr::col_character()),
    na = "",
    show_col_types = FALSE
  ) |>
  transmute(
    period = factor(.data[[time_column]], levels = time_levels, ordered = TRUE),
    value = readr::parse_double(.data[[numeric_column]])
  )
}

dashboard_data <- read_analysis_data(data_file)
reference_data <- read_analysis_data(reference_file)

# 4. Analyse --------------------------------------------------------------
# Match this dashboard view: exclude zero, negative and missing values.
dashboard_data <- dashboard_data |> filter(value > 0)
reference_data <- reference_data |> filter(value > 0)

# A 20% trimmed mean removes 20% from each tail before averaging.
# Each period also reports its median and contributing row count.
summarise_series <- function(data) {
  data |>
    group_by(period) |>
    summarise(
      mean = mean(value, trim = 0.2, na.rm = TRUE),
      median = median(value, na.rm = TRUE),
      n = n(),
      .groups = "drop"
    ) |>
    mutate(across(c(mean, median), ~ round(.x, 2)))
}

analysis_data <- summarise_series(dashboard_data)

# Add the full-data comparison only when the eligible row counts differ.
if (nrow(dashboard_data) != nrow(reference_data)) {
  analysis_data <- bind_rows(
    analysis_data |> mutate(series = "Filtered"),
    summarise_series(reference_data) |> mutate(series = "All")
  )
}

# 5. Plot -----------------------------------------------------------------
# The General's palette, in the same order as the dashboard.
palette <- c("#333333", "#17a2b8", "#eb8596", "#5c6b3c", "#d32f2f", "#e6b950", "#e0e0e0", 
"#90caf9", "#8e24aa", "#fcbb69", "#fdd835", "#1e88e5", "#bdbdbd", "#5e35b1", 
"#ff7043", "#00bfa5", "#ff4081", "#3949ab", "#f44336", "#c2185b", "#7b1fa2", 
"#512da8", "#303f9f", "#0288d1", "#0097a7", "#00796b", "#388e3c", "#689f38", 
"#afb42b", "#f57c00")

# Connecting period summaries describes a trend; it is not a fitted model.
if ("series" %in% names(analysis_data)) {
  plot <- ggplot(analysis_data, aes(period, mean, colour = series, group = series)) +
    geom_line(linewidth = 0.75) +
    geom_point() +
    scale_colour_manual(values = palette)
} else {
  plot <- ggplot(analysis_data, aes(period, mean, group = 1)) +
    geom_line(linewidth = 0.75, colour = "#333333") +
    geom_point(colour = "#333333")
}
plot <- plot + labs(x = time_column, y = numeric_column)

plot <- plot +
  theme_bw(base_size = 15) +
  theme(
    text = element_text(colour = "#333333"),
    axis.text = element_text(colour = "#333333"),
    legend.text = element_text(size = 10)
  ) +
  labs(title = plot_title)

if (!all(is.na(y_limits))) {
  plot <- plot + coord_cartesian(ylim = y_limits)
}

# 6. Save and display -----------------------------------------------------
# Save the calculated values as well as the image so the result is inspectable.
readr::write_csv(analysis_data, paste0(output_prefix, "_data.csv"), na = "")
ggsave(
  filename = paste0(output_prefix, ".png"),
  plot = plot,
  width = 9, height = 5.5, units = "in", dpi = 300
)

if (interactive()) print(plot)
