# The General | standalone dashboard analysis
# Run from the folder containing this script and its CSV files (R >= 4.1).
# The settings reproduce the current dashboard view at download time.
# Use mapped CSV data from the export, not the original uncleaned upload.
# PNG and analysis CSV outputs are written into this working directory.

# 1. Packages -------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(stringr)
# readr is called explicitly below. No Shiny or thegeneral installation is needed.

# 2. Settings -------------------------------------------------------------
data_file <- "dashboard_data.csv"
output_prefix <- "06_area_stacked"
plot_title <- "Example area_stacked"
time_column <- "Year_Quarter"
time_levels <- c("2024 Q2", "2024 Q3", "2024 Q4", "2025 Q1")
group_column <- "Cat_group"
numeric_column <- "Num_value"
# NA leaves that end of the y-axis automatic; limits zoom without dropping rows.
y_limits <- c(NA_real_, NA_real_)

# 3. Read and prepare data ------------------------------------------------
# Read text first so categorical codes such as 0012 keep their leading zeros.
# Parse only the mapped numeric measures. Rename columns to readable roles.
dashboard_data <-
  readr::read_csv(
    data_file,
    col_types = readr::cols(.default = readr::col_character()),
    na = "",
    show_col_types = FALSE
  ) |>
  transmute(
    period = factor(.data[[time_column]], levels = time_levels, ordered = TRUE),
    group = factor(.data[[group_column]]),
    value = readr::parse_double(.data[[numeric_column]])
  )

# 4. Analyse --------------------------------------------------------------
# Match this dashboard view: exclude zero, negative and missing values.
dashboard_data <- dashboard_data |> filter(value > 0)

# Calculate the arithmetic mean, median and row count for each group.
analysis_data <- dashboard_data |>
  group_by(period, group) |>
  summarise(
    mean = mean(value, na.rm = TRUE),
    median = median(value),
    n = n(),
    .groups = "drop"
  ) |>
  mutate(across(c(mean, median), ~ round(.x, 2)))

# Match the dashboard's case-insensitive NA/Other substring exclusions.
analysis_data <- analysis_data |>
  filter(!is.na(group), !str_detect(group, regex("NA|Other", ignore_case = TRUE))) |>
  mutate(across(c(group), droplevels))

# 5. Plot -----------------------------------------------------------------
# The General's palette, in the same order as the dashboard.
palette <- c("#333333", "#17a2b8", "#eb8596", "#5c6b3c", "#d32f2f", "#e6b950", "#e0e0e0", 
"#90caf9", "#8e24aa", "#fcbb69", "#fdd835", "#1e88e5", "#bdbdbd", "#5e35b1", 
"#ff7043", "#00bfa5", "#ff4081", "#3949ab", "#f44336", "#c2185b", "#7b1fa2", 
"#512da8", "#303f9f", "#0288d1", "#0097a7", "#00796b", "#388e3c", "#689f38", 
"#afb42b", "#f57c00")

# Complete absent period/group combinations for the stacked display only.
# These display zeros are not observed zero measurements in analysis_data.
plot_data <- analysis_data |>
  complete(period, group, fill = list(mean = 0), explicit = FALSE) |>
  mutate(period_position = as.integer(period))

# Each band is a group mean; the stacked height is a sum of means, not a total.
plot <- ggplot(plot_data, aes(period_position, mean, fill = group, group = group)) +
  geom_area(colour = "#333333", linewidth = 1) +
  scale_x_continuous(breaks = seq_along(time_levels), labels = time_levels) +
  scale_fill_manual(values = palette) +
  labs(x = time_column, y = numeric_column, fill = group_column)

plot <- plot +
  theme_classic(base_size = 15) +
  theme(
    text = element_text(colour = "#333333"),
    axis.text = element_text(colour = "#333333"),
    legend.text = element_text(size = 10)
  ) +
  labs(title = plot_title)

if (!all(is.na(y_limits))) {
  plot <- plot + coord_cartesian(ylim = y_limits)
}

# 6. Save and display -----------------------------------------------------
# Save the calculated values as well as the image so the result is inspectable.
readr::write_csv(analysis_data, paste0(output_prefix, "_data.csv"), na = "")
ggsave(
  filename = paste0(output_prefix, ".png"),
  plot = plot,
  width = 9, height = 5.5, units = "in", dpi = 300
)

if (interactive()) print(plot)
