# The General | standalone dashboard analysis
# Run from the folder containing this script and its CSV files (R >= 4.1).
# The settings reproduce the current dashboard view at download time.
# Use mapped CSV data from the export, not the original uncleaned upload.
# PNG and analysis CSV outputs are written into this working directory.

# 1. Packages -------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(stringr)
# readr is called explicitly below. No Shiny or thegeneral installation is needed.

# 2. Settings -------------------------------------------------------------
data_file <- "dashboard_data.csv"
output_prefix <- "04_bar_stacked"
plot_title <- "Example bar_stacked"
time_column <- "Month"
time_levels <- c("Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", 
"Mar")
group_column <- "Cat_group"
second_group_column <- "Cat_subgroup"
numeric_column <- "Num_value"
# NA leaves that end of the y-axis automatic; limits zoom without dropping rows.
y_limits <- c(NA_real_, NA_real_)

# 3. Read and prepare data ------------------------------------------------
# Read text first so categorical codes such as 0012 keep their leading zeros.
# Parse only the mapped numeric measures. Rename columns to readable roles.
dashboard_data <-
  readr::read_csv(
    data_file,
    col_types = readr::cols(.default = readr::col_character()),
    na = "",
    show_col_types = FALSE
  ) |>
  transmute(
    period = factor(.data[[time_column]], levels = time_levels, ordered = TRUE),
    group = factor(.data[[group_column]]),
    subgroup = factor(.data[[second_group_column]]),
    value = readr::parse_double(.data[[numeric_column]])
  )

# 4. Analyse --------------------------------------------------------------
# Match this dashboard view: exclude zero, negative and missing values.
dashboard_data <- dashboard_data |> filter(value > 0)

# Calculate the arithmetic mean, median and row count for each group.
analysis_data <- dashboard_data |>
  group_by(period, group, subgroup) |>
  summarise(
    mean = mean(value, na.rm = TRUE),
    median = median(value),
    n = n(),
    .groups = "drop"
  ) |>
  mutate(across(c(mean, median), ~ round(.x, 2)))

# The dashboard uses the last level of its ordered period field.
# For Month this is March (April-March financial-year order).
# This does not select the latest calendar date or pool all periods.
latest_period <- tail(time_levels, 1)
analysis_data <- analysis_data |> filter(period == latest_period)

# Match the dashboard's case-insensitive NA/Other substring exclusions.
analysis_data <- analysis_data |>
  filter(!is.na(group), !str_detect(group, regex("NA|Other", ignore_case = TRUE))) |>
  filter(!is.na(subgroup),
         !str_detect(subgroup, regex("NA|Other", ignore_case = TRUE))) |>
  mutate(across(c(group, subgroup), droplevels))

# 5. Plot -----------------------------------------------------------------
# The General's palette, in the same order as the dashboard.
palette <- c("#333333", "#17a2b8", "#eb8596", "#5c6b3c", "#d32f2f", "#e6b950", "#e0e0e0", 
"#90caf9", "#8e24aa", "#fcbb69", "#fdd835", "#1e88e5", "#bdbdbd", "#5e35b1", 
"#ff7043", "#00bfa5", "#ff4081", "#3949ab", "#f44336", "#c2185b", "#7b1fa2", 
"#512da8", "#303f9f", "#0288d1", "#0097a7", "#00796b", "#388e3c", "#689f38", 
"#afb42b", "#f57c00")

# Each segment is a subgroup mean. Stacked height is a sum of means;
# it is not a pooled mean, a count, or a sum of the original measurements.
plot <- ggplot(analysis_data, aes(group, mean, fill = subgroup)) +
  geom_col(colour = "#333333", linewidth = 0.75) +
  scale_fill_manual(values = palette) +
  labs(x = group_column, y = numeric_column, fill = second_group_column)

plot <- plot +
  theme_classic(base_size = 15) +
  theme(
    text = element_text(colour = "#333333"),
    axis.text = element_text(colour = "#333333"),
    legend.text = element_text(size = 10)
  ) +
  labs(title = plot_title)

if (!all(is.na(y_limits))) {
  plot <- plot + coord_cartesian(ylim = y_limits)
}

# 6. Save and display -----------------------------------------------------
# Save the calculated values as well as the image so the result is inspectable.
readr::write_csv(analysis_data, paste0(output_prefix, "_data.csv"), na = "")
ggsave(
  filename = paste0(output_prefix, ".png"),
  plot = plot,
  width = 9, height = 5.5, units = "in", dpi = 300
)

if (interactive()) print(plot)
