# The General | standalone dashboard analysis
# Run from the folder containing this script and its CSV files (R >= 4.1).
# The settings reproduce the current dashboard view at download time.
# Use mapped CSV data from the export, not the original uncleaned upload.
# PNG and analysis CSV outputs are written into this working directory.

# 1. Packages -------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(stringr)
# readr is called explicitly below. No Shiny or thegeneral installation is needed.

# 2. Settings -------------------------------------------------------------
data_file <- "dashboard_data.csv"
output_prefix <- "08_scatter"
plot_title <- "Example scatter"
group_column <- "Cat_group"
x_column <- "Num_x"
y_column <- "Num_y"
sample_seed <- 42L
# NA leaves that end of the y-axis automatic; limits zoom without dropping rows.
y_limits <- c(0, 800)

# 3. Read and prepare data ------------------------------------------------
# Read text first so categorical codes such as 0012 keep their leading zeros.
# Parse only the mapped numeric measures. Rename columns to readable roles.
dashboard_data <-
  readr::read_csv(
    data_file,
    col_types = readr::cols(.default = readr::col_character()),
    na = "",
    show_col_types = FALSE
  ) |>
  transmute(
    group = factor(.data[[group_column]]),
    x = readr::parse_double(.data[[x_column]]),
    y = readr::parse_double(.data[[y_column]])
  )

# 4. Analyse --------------------------------------------------------------
# Keep complete x/y pairs and their group labels.
analysis_data <- dashboard_data |>
  drop_na(group, x, y)

# The dashboard displays at most 1,000 points. A fixed seed makes this export
# repeatable; a newly drawn sample in the live dashboard can use different rows.
set.seed(sample_seed)
if (nrow(analysis_data) > 1000L) {
  analysis_data <- analysis_data |> slice_sample(n = 1000L)
}
analysis_data <- analysis_data |> mutate(group = droplevels(group))

# 5. Plot -----------------------------------------------------------------
# The General's palette, in the same order as the dashboard.
palette <- c("#333333", "#17a2b8", "#eb8596", "#5c6b3c", "#d32f2f", "#e6b950", "#e0e0e0", 
"#90caf9", "#8e24aa", "#fcbb69", "#fdd835", "#1e88e5", "#bdbdbd", "#5e35b1", 
"#ff7043", "#00bfa5", "#ff4081", "#3949ab", "#f44336", "#c2185b", "#7b1fa2", 
"#512da8", "#303f9f", "#0288d1", "#0097a7", "#00796b", "#388e3c", "#689f38", 
"#afb42b", "#f57c00")

# Fit a separate ordinary least-squares line for each colour group.
# Dashed lines show association, not causation; confidence bands are hidden.
plot <- ggplot(analysis_data, aes(x, y, colour = group)) +
  geom_point(size = 3, alpha = 0.6) +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE, linetype = "dashed") +
  scale_colour_manual(values = palette) +
  labs(x = x_column, y = y_column, colour = group_column)

plot <- plot +
  theme_bw(base_size = 15) +
  theme(
    text = element_text(colour = "#333333"),
    axis.text = element_text(colour = "#333333"),
    legend.text = element_text(size = 10)
  ) +
  labs(title = plot_title)

if (!all(is.na(y_limits))) {
  plot <- plot + coord_cartesian(ylim = y_limits)
}

# 6. Save and display -----------------------------------------------------
# Save the calculated values as well as the image so the result is inspectable.
readr::write_csv(analysis_data, paste0(output_prefix, "_data.csv"), na = "")
ggsave(
  filename = paste0(output_prefix, ".png"),
  plot = plot,
  width = 9, height = 5.5, units = "in", dpi = 300
)

if (interactive()) print(plot)
